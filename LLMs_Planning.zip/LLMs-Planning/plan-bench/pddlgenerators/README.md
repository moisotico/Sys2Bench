## PDDL Generators for IPC Planning Domains

Source repo: [pddl-generators](https://github.com/AI-Planning/pddl-generators)